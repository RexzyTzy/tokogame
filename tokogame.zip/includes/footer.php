<footer>
    <p>&copy; <?php echo date("Y"); ?> Tokogame. All Rights Reserved.</p>
</footer>
</body>
</html>